import { UserRound, TrendingDown, Workflow, Lock } from "lucide-react";
import { Reveal } from "./Reveal";

const BENEFITS = [
  {
    icon: UserRound,
    title: "Atendimento Personalizado",
    text: "Cada cliente recebe uma análise individual para encontrar a melhor proposta.",
  },
  {
    icon: TrendingDown,
    title: "Melhores Taxas",
    text: "Buscamos as melhores condições disponíveis entre nossos parceiros.",
  },
  {
    icon: Workflow,
    title: "Processo Simplificado",
    text: "Pouca burocracia e acompanhamento durante toda a contratação.",
  },
  {
    icon: Lock,
    title: "Segurança",
    text: "Seus dados protegidos durante todo o atendimento.",
  },
];

export function Benefits() {
  return (
    <section id="beneficios" className="scroll-mt-24 bg-surface py-24 lg:py-32">
      <div className="mx-auto max-w-7xl px-5 lg:px-8">
        <Reveal className="max-w-2xl">
          <p className="text-sm font-semibold uppercase tracking-[0.2em] text-emerald-brand">
            Benefícios
          </p>
          <h2 className="mt-4 text-3xl font-extrabold text-ink sm:text-4xl lg:text-5xl">
            Por que escolher a Rede Credi?
          </h2>
        </Reveal>

        <div className="mt-14 grid gap-5 sm:grid-cols-2 lg:grid-cols-4">
          {BENEFITS.map((b, i) => (
            <Reveal key={b.title} delay={i * 90}>
              <article className="group h-full rounded-3xl border border-border bg-card p-7 shadow-soft transition-all duration-300 hover:-translate-y-1.5 hover:border-emerald-brand/40 hover:shadow-lift">
                <span className="grid size-12 place-items-center rounded-2xl bg-emerald-soft transition-colors group-hover:bg-gradient-emerald">
                  <b.icon
                    className="size-5 text-petrol transition-colors group-hover:text-primary-foreground"
                    strokeWidth={2}
                  />
                </span>
                <h3 className="mt-6 text-lg font-bold text-ink">{b.title}</h3>
                <p className="mt-2.5 text-sm leading-relaxed text-muted-foreground">{b.text}</p>
              </article>
            </Reveal>
          ))}
        </div>
      </div>
    </section>
  );
}

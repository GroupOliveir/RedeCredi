import {
  Accordion,
  AccordionContent,
  AccordionItem,
  AccordionTrigger,
} from "@/components/ui/accordion";
import { Reveal } from "./Reveal";

export const FAQ_ITEMS = [
  {
    q: "Quem pode solicitar crédito consignado?",
    a: "Aposentados e pensionistas do INSS, servidores públicos federais, estaduais e municipais, militares e funcionários de empresas conveniadas com margem consignável disponível.",
  },
  {
    q: "Quais documentos são necessários?",
    a: "Em geral: documento de identidade com foto, CPF, comprovante de residência atualizado e o extrato de benefício ou contracheque. Nossa equipe confirma a lista exata para o seu caso.",
  },
  {
    q: "Quanto tempo leva a aprovação?",
    a: "A simulação é feita no mesmo dia e, com a documentação em mãos, a aprovação normalmente acontece em até 24 horas úteis.",
  },
  {
    q: "Como funciona a portabilidade?",
    a: "Analisamos o seu contrato atual e buscamos entre nossos parceiros uma taxa menor. Se compensar, transferimos o contrato e você passa a pagar parcelas mais baixas.",
  },
  {
    q: "O atendimento é online?",
    a: "Sim. Todo o atendimento pode ser feito pelo WhatsApp, com assinatura digital e acompanhamento humano em cada etapa.",
  },
];

export function Faq() {
  return (
    <section id="faq" className="scroll-mt-24 bg-surface py-24 lg:py-32">
      <div className="mx-auto grid max-w-7xl gap-12 px-5 lg:grid-cols-[0.8fr_1.2fr] lg:px-8">
        <Reveal>
          <p className="text-sm font-semibold uppercase tracking-[0.2em] text-emerald-brand">
            Perguntas frequentes
          </p>
          <h2 className="mt-4 text-3xl font-extrabold text-ink sm:text-4xl">
            Tudo o que você precisa saber
          </h2>
          <p className="mt-4 text-base leading-relaxed text-muted-foreground">
            Não encontrou sua dúvida? Fale com um especialista pelo WhatsApp — respondemos em
            minutos.
          </p>
        </Reveal>

        <Reveal delay={120}>
          <Accordion type="single" collapsible className="w-full">
            {FAQ_ITEMS.map((item) => (
              <AccordionItem
                key={item.q}
                value={item.q}
                className="mb-3 rounded-2xl border border-border bg-card px-6 shadow-soft"
              >
                <AccordionTrigger className="py-5 text-left text-base font-semibold text-ink hover:no-underline">
                  {item.q}
                </AccordionTrigger>
                <AccordionContent className="pb-5 text-sm leading-relaxed text-muted-foreground">
                  {item.a}
                </AccordionContent>
              </AccordionItem>
            ))}
          </Accordion>
        </Reveal>
      </div>
    </section>
  );
}

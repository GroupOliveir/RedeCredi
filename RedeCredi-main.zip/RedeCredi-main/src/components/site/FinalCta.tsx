import { MessageCircle } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Reveal } from "./Reveal";
import { whatsappLink, DEFAULT_WHATSAPP_MESSAGE } from "@/lib/site";
import { trackEvent } from "@/lib/analytics";

export function FinalCta() {
  return (
    <section className="px-5 pb-24 lg:px-8 lg:pb-32">
      <Reveal>
        <div className="relative mx-auto max-w-7xl overflow-hidden rounded-[2.5rem] bg-gradient-ink px-7 py-20 text-center sm:px-12">
          <div
            aria-hidden
            className="pointer-events-none absolute -bottom-40 left-1/2 size-[34rem] -translate-x-1/2 rounded-full bg-emerald-brand/20 blur-3xl"
          />
          <div className="relative mx-auto max-w-2xl">
            <h2 className="text-3xl font-extrabold text-background sm:text-4xl lg:text-5xl">
              Precisa reorganizar sua vida financeira?
            </h2>
            <p className="mt-5 text-lg leading-relaxed text-background/70">
              Nossa equipe está pronta para encontrar a melhor solução para o seu caso.
            </p>
            <Button
              asChild
              variant="emerald"
              size="hero"
              className="mt-10 h-16 px-10 text-base"
              onClick={() => trackEvent("whatsapp_click", { location: "cta_final" })}
            >
              <a href={whatsappLink(DEFAULT_WHATSAPP_MESSAGE)} target="_blank" rel="noreferrer">
                <MessageCircle /> Falar com um Especialista no WhatsApp
              </a>
            </Button>
          </div>
        </div>
      </Reveal>
    </section>
  );
}

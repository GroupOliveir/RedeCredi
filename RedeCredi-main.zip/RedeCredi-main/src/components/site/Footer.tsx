import { MessageCircle, Instagram } from "lucide-react";
import { Logo } from "./Logo";
import { whatsappLink, DEFAULT_WHATSAPP_MESSAGE, CONTACT } from "@/lib/site";

const MENU = [
  { label: "Benefícios", href: "#beneficios" },
  { label: "Como funciona", href: "#como-funciona" },
  { label: "Depoimentos", href: "#depoimentos" },
  { label: "Dúvidas", href: "#faq" },
];

const SERVICES = [
  { label: "Crédito Consignado", href: "#produtos" },
  { label: "Refinanciamento", href: "#produtos" },
  { label: "Portabilidade", href: "#produtos" },
  { label: "Empréstimo com Garantia", href: "#produtos" },
];

export function Footer() {
  return (
    <footer className="border-t border-border bg-surface">
      <div className="mx-auto max-w-7xl px-5 py-16 lg:px-8">
        <div className="grid gap-12 md:grid-cols-2 lg:grid-cols-4">
          <div>
            <Logo />
            <p className="mt-5 max-w-xs text-sm leading-relaxed text-muted-foreground">
              Correspondente bancário especializado em crédito consignado, com atendimento
              humanizado e as melhores condições do mercado.
            </p>
            <div className="mt-6 flex gap-3">
              <a
                href={whatsappLink(DEFAULT_WHATSAPP_MESSAGE)}
                target="_blank"
                rel="noreferrer"
                aria-label="WhatsApp da Rede Credi"
                className="grid size-11 place-items-center rounded-xl border border-border bg-card text-ink transition-colors hover:border-emerald-brand hover:text-emerald-brand"
              >
                <MessageCircle className="size-5" />
              </a>
              <a
                href={CONTACT.instagram}
                target="_blank"
                rel="noreferrer"
                aria-label="Instagram da Rede Credi"
                className="grid size-11 place-items-center rounded-xl border border-border bg-card text-ink transition-colors hover:border-emerald-brand hover:text-emerald-brand"
              >
                <Instagram className="size-5" />
              </a>
            </div>
          </div>

          <nav aria-label="Menu">
            <h3 className="text-sm font-bold text-ink">Menu</h3>
            <ul className="mt-5 space-y-3">
              {MENU.map((i) => (
                <li key={i.label}>
                  <a
                    href={i.href}
                    className="text-sm text-muted-foreground transition-colors hover:text-emerald-brand"
                  >
                    {i.label}
                  </a>
                </li>
              ))}
            </ul>
          </nav>

          <nav aria-label="Serviços">
            <h3 className="text-sm font-bold text-ink">Serviços</h3>
            <ul className="mt-5 space-y-3">
              {SERVICES.map((i) => (
                <li key={i.label}>
                  <a
                    href={i.href}
                    className="text-sm text-muted-foreground transition-colors hover:text-emerald-brand"
                  >
                    {i.label}
                  </a>
                </li>
              ))}
            </ul>
          </nav>

          <nav aria-label="Legal">
            <h3 className="text-sm font-bold text-ink">Legal</h3>
            <ul className="mt-5 space-y-3">
              <li>
                <a
                  href="/politica-de-privacidade"
                  className="text-sm text-muted-foreground transition-colors hover:text-emerald-brand"
                >
                  Política de Privacidade
                </a>
              </li>
              <li>
                <a
                  href="/termos-de-uso"
                  className="text-sm text-muted-foreground transition-colors hover:text-emerald-brand"
                >
                  Termos de Uso
                </a>
              </li>
            </ul>
          </nav>
        </div>

        <div className="mt-14 flex flex-col gap-3 border-t border-border pt-8 sm:flex-row sm:items-center sm:justify-between">
          <p className="text-xs text-muted-foreground">
            Direitos Reservados © {new Date().getFullYear()} Rede Credi
          </p>
          <p className="text-xs text-muted-foreground">
            A Rede Credi não cobra taxas antecipadas para liberação de crédito.
          </p>
        </div>
      </div>
    </footer>
  );
}

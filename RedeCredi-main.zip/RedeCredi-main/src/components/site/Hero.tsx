import { MessageCircle, Sparkles, ArrowRight, Check } from "lucide-react";
import { Button } from "@/components/ui/button";
import heroPhone from "@/assets/hero-phone.png";
import { whatsappLink, DEFAULT_WHATSAPP_MESSAGE } from "@/lib/site";
import { trackEvent } from "@/lib/analytics";

const FLOATING = [
  { label: "Aprovação rápida", className: "left-0 top-[14%]", delay: "0s" },
  { label: "Parcelas reduzidas", className: "right-0 top-[32%]", delay: "1.2s" },
  { label: "Atendimento humanizado", className: "left-0 bottom-[26%]", delay: "2.1s" },
  { label: "Segurança em todo o processo", className: "right-0 bottom-[8%]", delay: "3s" },
];

export function Hero() {
  return (
    <section id="topo" className="relative overflow-hidden pt-32 pb-20 lg:pt-40 lg:pb-28">
      <div
        aria-hidden
        className="pointer-events-none absolute -right-40 -top-40 size-[36rem] rounded-full bg-emerald-soft blur-3xl"
      />
      <div
        aria-hidden
        className="pointer-events-none absolute -left-52 top-72 size-[30rem] rounded-full bg-petrol-soft blur-3xl"
      />

      <div className="relative mx-auto grid max-w-7xl items-center gap-14 px-5 lg:grid-cols-[1.05fr_1fr] lg:gap-10 lg:px-8">
        <div className="animate-rise">
          <span className="inline-flex items-center gap-2 rounded-full border border-emerald-brand/30 bg-emerald-soft px-4 py-1.5 text-xs font-semibold tracking-wide text-petrol uppercase">
            <Sparkles className="size-3.5 text-emerald-brand" />
            Crédito consignado sem burocracia
          </span>

          <h1 className="mt-6 text-4xl font-extrabold leading-[1.05] text-ink sm:text-5xl lg:text-[3.6rem]">
            Crédito consignado com atendimento{" "}
            <span className="text-emerald-brand">rápido, seguro</span> e personalizado.
          </h1>

          <p className="mt-6 max-w-xl text-lg leading-relaxed text-muted-foreground">
            Encontramos a melhor solução financeira para você com transparência, agilidade e as
            melhores condições do mercado.
          </p>

          <div className="mt-9 flex flex-col gap-3 sm:flex-row">
            <Button asChild variant="emerald" size="hero">
              <a href="#simulacao" onClick={() => trackEvent("cta_click", { cta: "simular_agora" })}>
                Simular Agora <ArrowRight />
              </a>
            </Button>
            <Button
              asChild
              variant="outlineInk"
              size="hero"
              onClick={() => trackEvent("whatsapp_click", { location: "hero" })}
            >
              <a href={whatsappLink(DEFAULT_WHATSAPP_MESSAGE)} target="_blank" rel="noreferrer">
                <MessageCircle /> Falar no WhatsApp
              </a>
            </Button>
          </div>

          <dl className="mt-12 grid max-w-lg grid-cols-3 gap-6 border-t border-border pt-8">
            {[
              ["+1000", "Clientes atendidos"],
              ["24h", "Resposta média"],
              ["100%", "Processo seguro"],
            ].map(([value, label]) => (
              <div key={label}>
                <dt className="text-2xl font-extrabold text-ink">{value}</dt>
                <dd className="mt-1 text-xs text-muted-foreground">{label}</dd>
              </div>
            ))}
          </dl>
        </div>

        <div className="relative mx-auto w-full max-w-md lg:max-w-none">
          <div className="relative px-10 sm:px-16 lg:px-20">
            <img
              src={heroPhone}
              alt="Celular exibindo a aprovação de um crédito consignado no aplicativo"
              width={1024}
              height={1280}
              className="relative z-10 w-full animate-float drop-shadow-2xl"
            />
            {FLOATING.map((card) => (
              <div
                key={card.label}
                style={{ animationDelay: card.delay }}
                className={`absolute z-20 hidden animate-float items-center gap-2 rounded-2xl border border-border bg-card/90 px-3.5 py-2.5 shadow-lift backdrop-blur sm:flex ${card.className}`}
              >
                <span className="grid size-5 shrink-0 place-items-center rounded-full bg-gradient-emerald">
                  <Check className="size-3 text-primary-foreground" strokeWidth={3} />
                </span>
                <span className="text-xs font-semibold text-ink">{card.label}</span>
              </div>
            ))}
          </div>
        </div>
      </div>
    </section>
  );
}

import { Reveal } from "./Reveal";

const STEPS = [
  { n: "1", title: "Solicite uma simulação", text: "Fale com a gente pelo WhatsApp ou formulário." },
  { n: "2", title: "Analisamos seu perfil", text: "Consultamos margem e condições disponíveis." },
  { n: "3", title: "Apresentamos a melhor proposta", text: "Taxas e parcelas com total transparência." },
  { n: "4", title: "Você recebe seu crédito", text: "Contratação segura e acompanhada do início ao fim." },
];

export function HowItWorks() {
  return (
    <section id="como-funciona" className="scroll-mt-24 py-24 lg:py-32">
      <div className="mx-auto max-w-7xl px-5 lg:px-8">
        <Reveal className="max-w-2xl">
          <p className="text-sm font-semibold uppercase tracking-[0.2em] text-emerald-brand">
            Como funciona
          </p>
          <h2 className="mt-4 text-3xl font-extrabold text-ink sm:text-4xl lg:text-5xl">
            Quatro etapas simples até o seu crédito
          </h2>
        </Reveal>

        <ol className="relative mt-16 grid gap-10 lg:grid-cols-4 lg:gap-6">
          <span
            aria-hidden
            className="absolute left-6 top-4 hidden h-px w-[calc(100%-3rem)] bg-border lg:block"
          />
          {STEPS.map((s, i) => (
            <Reveal key={s.n} delay={i * 120}>
              <li className="relative flex gap-5 lg:block">
                <div className="flex flex-col items-center lg:block">
                  <span className="relative z-10 grid size-12 shrink-0 place-items-center rounded-2xl bg-gradient-ink text-lg font-extrabold text-background lg:size-14">
                    {s.n}
                  </span>
                  {i < STEPS.length - 1 && (
                    <span aria-hidden className="mt-2 w-px flex-1 bg-border lg:hidden" />
                  )}
                </div>
                <div className="pb-8 lg:pb-0 lg:pt-7">
                  <h3 className="text-lg font-bold text-ink">{s.title}</h3>
                  <p className="mt-2 text-sm leading-relaxed text-muted-foreground">{s.text}</p>
                </div>
              </li>
            </Reveal>
          ))}
        </ol>
      </div>
    </section>
  );
}

import { ShieldCheck } from "lucide-react";

export function Logo({ variant = "dark" }: { variant?: "dark" | "light" }) {
  return (
    <span className="flex items-center gap-2.5">
      <span className="grid size-9 shrink-0 place-items-center rounded-xl bg-gradient-emerald shadow-glow">
        <ShieldCheck className="size-5 text-primary-foreground" strokeWidth={2.4} />
      </span>
      <span
        className={
          variant === "light"
            ? "text-lg font-extrabold tracking-tight text-background"
            : "text-lg font-extrabold tracking-tight text-ink"
        }
      >
        Rede<span className="text-emerald-brand">Credi</span>
      </span>
    </span>
  );
}

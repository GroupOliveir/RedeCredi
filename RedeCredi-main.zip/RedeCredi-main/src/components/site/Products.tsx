import { Wallet, RefreshCw, ArrowLeftRight, Car, ArrowUpRight } from "lucide-react";
import { Reveal } from "./Reveal";
import { whatsappLink } from "@/lib/site";
import { trackEvent } from "@/lib/analytics";

const PRODUCTS = [
  {
    icon: Wallet,
    title: "Crédito Consignado",
    text: "Para aposentados, pensionistas e servidores.",
  },
  {
    icon: RefreshCw,
    title: "Refinanciamento",
    text: "Reduza parcelas e reorganize sua vida financeira.",
  },
  {
    icon: ArrowLeftRight,
    title: "Portabilidade",
    text: "Transfira seu contrato para condições melhores.",
  },
  {
    icon: Car,
    title: "Empréstimo com Garantia",
    text: "Mais crédito com taxas reduzidas.",
  },
];

export function Products() {
  return (
    <section id="produtos" className="scroll-mt-24 bg-surface py-24 lg:py-32">
      <div className="mx-auto max-w-7xl px-5 lg:px-8">
        <Reveal className="max-w-2xl">
          <p className="text-sm font-semibold uppercase tracking-[0.2em] text-emerald-brand">
            Produtos
          </p>
          <h2 className="mt-4 text-3xl font-extrabold text-ink sm:text-4xl lg:text-5xl">
            Soluções para cada momento da sua vida
          </h2>
        </Reveal>

        <div className="mt-14 grid gap-5 sm:grid-cols-2">
          {PRODUCTS.map((p, i) => (
            <Reveal key={p.title} delay={i * 90}>
              <a
                href={whatsappLink(`Olá! Tenho interesse em ${p.title}. Pode me ajudar?`)}
                target="_blank"
                rel="noreferrer"
                onClick={() => trackEvent("whatsapp_click", { location: "produtos", produto: p.title })}
                className="group flex h-full items-start gap-5 rounded-3xl border border-border bg-card p-8 shadow-soft transition-all duration-300 hover:-translate-y-1.5 hover:border-emerald-brand/40 hover:shadow-lift"
              >
                <span className="grid size-12 shrink-0 place-items-center rounded-2xl bg-petrol-soft">
                  <p.icon className="size-5 text-petrol" strokeWidth={2} />
                </span>
                <span className="min-w-0 flex-1">
                  <span className="flex items-center gap-2 text-lg font-bold text-ink">
                    {p.title}
                    <ArrowUpRight className="size-4 text-emerald-brand opacity-0 transition-opacity group-hover:opacity-100" />
                  </span>
                  <span className="mt-2 block text-sm leading-relaxed text-muted-foreground">
                    {p.text}
                  </span>
                </span>
              </a>
            </Reveal>
          ))}
        </div>
      </div>
    </section>
  );
}

import { useState, type FormEvent } from "react";
import { MessageCircle, ShieldCheck } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import { Reveal } from "./Reveal";
import { whatsappLink } from "@/lib/site";
import { trackEvent } from "@/lib/analytics";

const TIPOS = [
  "Crédito Consignado",
  "Refinanciamento",
  "Portabilidade",
  "Empréstimo com Garantia",
];

const PERFIS = ["Aposentado / Pensionista INSS", "Servidor público", "Militar", "CLT conveniado", "Outro"];

export function SimulationForm() {
  const [nome, setNome] = useState("");
  const [telefone, setTelefone] = useState("");
  const [tipo, setTipo] = useState<string>("Crédito Consignado");
  const [perfil, setPerfil] = useState<string>("Aposentado / Pensionista INSS");
  const [valor, setValor] = useState("");

  function handleSubmit(e: FormEvent) {
    e.preventDefault();
    const message = [
      "Olá, Rede Credi! Quero uma simulação.",
      `Nome: ${nome}`,
      `Telefone: ${telefone}`,
      `Produto: ${tipo}`,
      `Perfil: ${perfil}`,
      valor ? `Valor desejado: R$ ${valor}` : null,
    ]
      .filter(Boolean)
      .join("\n");

    trackEvent("generate_lead", { method: "whatsapp_form", produto: tipo });
    window.open(whatsappLink(message), "_blank", "noopener");
  }

  return (
    <section id="simulacao" className="scroll-mt-24 py-24 lg:py-32">
      <div className="mx-auto grid max-w-7xl items-center gap-12 px-5 lg:grid-cols-2 lg:px-8">
        <Reveal>
          <p className="text-sm font-semibold uppercase tracking-[0.2em] text-emerald-brand">
            Simulação gratuita
          </p>
          <h2 className="mt-4 text-3xl font-extrabold text-ink sm:text-4xl lg:text-5xl">
            Faça sua simulação em menos de 1 minuto
          </h2>
          <p className="mt-5 max-w-lg text-lg leading-relaxed text-muted-foreground">
            Preencha os dados e continue a conversa direto no WhatsApp com um especialista da Rede
            Credi. Sem custo e sem compromisso.
          </p>
          <p className="mt-8 inline-flex items-center gap-2 rounded-full bg-emerald-soft px-4 py-2 text-sm font-semibold text-petrol">
            <ShieldCheck className="size-4 text-emerald-brand" /> Seus dados não são armazenados
          </p>
        </Reveal>

        <Reveal delay={120}>
          <form
            onSubmit={handleSubmit}
            className="rounded-3xl border border-border bg-card p-7 shadow-lift sm:p-9"
          >
            <div className="grid gap-5">
              <div className="grid gap-2">
                <Label htmlFor="nome">Nome completo</Label>
                <Input
                  id="nome"
                  required
                  value={nome}
                  onChange={(e) => setNome(e.target.value)}
                  placeholder="Como podemos te chamar?"
                  className="h-12 rounded-xl"
                />
              </div>

              <div className="grid gap-2">
                <Label htmlFor="telefone">WhatsApp</Label>
                <Input
                  id="telefone"
                  required
                  type="tel"
                  value={telefone}
                  onChange={(e) => setTelefone(e.target.value)}
                  placeholder="(00) 00000-0000"
                  className="h-12 rounded-xl"
                />
              </div>

              <div className="grid gap-5 sm:grid-cols-2">
                <div className="grid gap-2">
                  <Label htmlFor="tipo">Produto</Label>
                  <Select value={tipo} onValueChange={setTipo}>
                    <SelectTrigger id="tipo" className="h-12 rounded-xl">
                      <SelectValue />
                    </SelectTrigger>
                    <SelectContent>
                      {TIPOS.map((t) => (
                        <SelectItem key={t} value={t}>
                          {t}
                        </SelectItem>
                      ))}
                    </SelectContent>
                  </Select>
                </div>

                <div className="grid gap-2">
                  <Label htmlFor="valor">Valor desejado</Label>
                  <Input
                    id="valor"
                    inputMode="numeric"
                    value={valor}
                    onChange={(e) => setValor(e.target.value)}
                    placeholder="Ex.: 10.000"
                    className="h-12 rounded-xl"
                  />
                </div>
              </div>

              <div className="grid gap-2">
                <Label htmlFor="perfil">Seu perfil</Label>
                <Select value={perfil} onValueChange={setPerfil}>
                  <SelectTrigger id="perfil" className="h-12 rounded-xl">
                    <SelectValue />
                  </SelectTrigger>
                  <SelectContent>
                    {PERFIS.map((p) => (
                      <SelectItem key={p} value={p}>
                        {p}
                      </SelectItem>
                    ))}
                  </SelectContent>
                </Select>
              </div>

              <Button type="submit" variant="emerald" size="hero" className="mt-2 w-full">
                <MessageCircle /> Enviar e falar no WhatsApp
              </Button>
              <p className="text-center text-xs text-muted-foreground">
                Ao enviar, você será redirecionado para o WhatsApp da Rede Credi.
              </p>
            </div>
          </form>
        </Reveal>
      </div>
    </section>
  );
}

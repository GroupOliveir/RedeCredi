import { Reveal } from "./Reveal";

const STATS = [
  { value: "+1000", label: "Clientes atendidos" },
  { value: "100%", label: "Atendimento humanizado" },
  { value: "24h", label: "Resposta rápida" },
  { value: "0", label: "Riscos aos seus dados" },
];

export function Stats() {
  return (
    <section className="relative overflow-hidden bg-gradient-ink py-24 lg:py-32">
      <div
        aria-hidden
        className="pointer-events-none absolute -left-32 top-0 size-[28rem] rounded-full bg-emerald-brand/15 blur-3xl"
      />
      <div className="relative mx-auto max-w-7xl px-5 lg:px-8">
        <Reveal className="max-w-2xl">
          <p className="text-sm font-semibold uppercase tracking-[0.2em] text-emerald-brand">
            Diferenciais
          </p>
          <h2 className="mt-4 text-3xl font-extrabold text-background sm:text-4xl lg:text-5xl">
            Números que traduzem confiança
          </h2>
        </Reveal>

        <div className="mt-16 grid gap-10 sm:grid-cols-2 lg:grid-cols-4">
          {STATS.map((s, i) => (
            <Reveal key={s.label} delay={i * 110}>
              <div className="border-t border-background/15 pt-6">
                <p className="text-5xl font-extrabold tracking-tight text-emerald-brand lg:text-6xl">
                  {s.value}
                </p>
                <p className="mt-3 text-sm font-medium text-background/70">{s.label}</p>
              </div>
            </Reveal>
          ))}
        </div>
      </div>
    </section>
  );
}

import { Star, Quote } from "lucide-react";
import {
  Carousel,
  CarouselContent,
  CarouselItem,
  CarouselNext,
  CarouselPrevious,
} from "@/components/ui/carousel";
import { Reveal } from "./Reveal";

const TESTIMONIALS = [
  {
    text: "Fui atendido rapidamente e consegui uma condição muito melhor do que esperava.",
    name: "Antônio R.",
    role: "Aposentado — INSS",
  },
  {
    text: "Equipe extremamente atenciosa e transparente.",
    name: "Marli S.",
    role: "Servidora pública",
  },
  {
    text: "Processo simples e sem complicações.",
    name: "Cleber M.",
    role: "Pensionista",
  },
];

export function Testimonials() {
  return (
    <section id="depoimentos" className="scroll-mt-24 py-24 lg:py-32">
      <div className="mx-auto max-w-7xl px-5 lg:px-8">
        <Reveal className="max-w-2xl">
          <p className="text-sm font-semibold uppercase tracking-[0.2em] text-emerald-brand">
            Depoimentos
          </p>
          <h2 className="mt-4 text-3xl font-extrabold text-ink sm:text-4xl lg:text-5xl">
            Quem já contratou com a gente
          </h2>
        </Reveal>

        <Reveal delay={120}>
          <Carousel opts={{ align: "start", loop: true }} className="mt-14">
            <CarouselContent className="-ml-5">
              {TESTIMONIALS.map((t) => (
                <CarouselItem key={t.name} className="pl-5 sm:basis-1/2 lg:basis-1/3">
                  <figure className="flex h-full flex-col rounded-3xl border border-border bg-card p-8 shadow-soft">
                    <Quote className="size-7 text-emerald-brand/40" />
                    <div className="mt-5 flex gap-0.5" aria-label="Avaliação 5 de 5">
                      {Array.from({ length: 5 }).map((_, i) => (
                        <Star
                          key={i}
                          className="size-4 fill-emerald-brand text-emerald-brand"
                        />
                      ))}
                    </div>
                    <blockquote className="mt-4 flex-1 text-base leading-relaxed text-ink">
                      “{t.text}”
                    </blockquote>
                    <figcaption className="mt-6 border-t border-border pt-5">
                      <span className="block text-sm font-bold text-ink">{t.name}</span>
                      <span className="block text-xs text-muted-foreground">{t.role}</span>
                    </figcaption>
                  </figure>
                </CarouselItem>
              ))}
            </CarouselContent>
            <div className="mt-8 flex gap-3">
              <CarouselPrevious className="static translate-y-0 size-11 rounded-full" />
              <CarouselNext className="static translate-y-0 size-11 rounded-full" />
            </div>
          </Carousel>
        </Reveal>
      </div>
    </section>
  );
}

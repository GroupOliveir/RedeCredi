import { useEffect, useState } from "react";
import { MessageCircle } from "lucide-react";
import { whatsappLink, DEFAULT_WHATSAPP_MESSAGE } from "@/lib/site";
import { trackEvent } from "@/lib/analytics";
import { cn } from "@/lib/utils";

export function WhatsAppFab() {
  const [show, setShow] = useState(false);

  useEffect(() => {
    const onScroll = () => setShow(window.scrollY > 400);
    onScroll();
    window.addEventListener("scroll", onScroll, { passive: true });
    return () => window.removeEventListener("scroll", onScroll);
  }, []);

  return (
    <a
      href={whatsappLink(DEFAULT_WHATSAPP_MESSAGE)}
      target="_blank"
      rel="noreferrer"
      aria-label="Falar no WhatsApp"
      onClick={() => trackEvent("whatsapp_click", { location: "botao_flutuante" })}
      className={cn(
        "fixed bottom-6 right-5 z-50 flex items-center gap-2.5 rounded-full bg-gradient-emerald px-5 py-4 shadow-glow transition-all duration-300 hover:brightness-105",
        show ? "translate-y-0 opacity-100" : "pointer-events-none translate-y-6 opacity-0",
      )}
    >
      <MessageCircle className="size-6 text-primary-foreground" />
      <span className="hidden text-sm font-bold text-primary-foreground sm:inline">
        Falar no WhatsApp
      </span>
    </a>
  );
}

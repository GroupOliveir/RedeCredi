/**
 * Google Analytics (GA4) — estrutura pronta.
 * Defina VITE_GA_MEASUREMENT_ID para ativar o carregamento do gtag.js.
 */

declare global {
  interface Window {
    dataLayer?: unknown[];
  }
}

export function gtag(...args: unknown[]) {
  if (typeof window === "undefined") return;
  window.dataLayer = window.dataLayer || [];
  window.dataLayer.push(args);
}

let initialized = false;

export function initAnalytics() {
  if (typeof window === "undefined" || initialized) return;
  const measurementId = import.meta.env["VITE_GA_MEASUREMENT_ID"] as string | undefined;
  if (!measurementId) return;
  initialized = true;

  const script = document.createElement("script");
  script.async = true;
  script.src = `https://www.googletagmanager.com/gtag/js?id=${measurementId}`;
  document.head.appendChild(script);

  gtag("js", new Date());
  gtag("config", measurementId);
}

export function trackEvent(name: string, params?: Record<string, unknown>) {
  gtag("event", name, params ?? {});
}

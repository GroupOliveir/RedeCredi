export const WHATSAPP_NUMBER = "5511999999999";

export const CONTACT = {
  whatsappNumber: WHATSAPP_NUMBER,
  instagram: "https://instagram.com/redecredi",
};

export function whatsappLink(message: string) {
  return `https://wa.me/${WHATSAPP_NUMBER}?text=${encodeURIComponent(message)}`;
}

export const DEFAULT_WHATSAPP_MESSAGE =
  "Olá! Vim pelo site da Rede Credi e gostaria de falar com um especialista sobre crédito consignado.";
